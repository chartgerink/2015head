# First, set 'wd' to the folder with this script in it (must contain sub-folders called "raw_data", with the raw data in it, and "processed_data", which will receive the output files containing the results)
wd <- "C:/Users/Chris/Dropbox/projects/2015head/FILES_FOR_DRYAD/1. TEXT_MINING"

##########################

# Set your working directory
setwd(wd)

# Load the functions contained in functions.r
source("functions.r")

# Load the p values data file, and the file containing the FoR categories for each journal
d <- read.csv("raw_data/p.values.csv", row.names=1)
journal.categories <- read.csv("raw_data/journal.categories.csv", row.names=1)

# Get rid of papers that did not yield any p values
d <- d[!is.na(d$p.value), ]

# only keep papers with a single DOI (tyipcally we lose ~100K files here)
# NB some papers really have 0 or >1 DOI
d <- d[which(d$num.dois==1),]

# only keep papers for which we have >0 results sections (e.g. reviews and commentaries often have 0 results sections)
d <- d[which(d$num.results.sections > 0),]

# some papers have (legitimately, I've checked) zero authors. Remove these.
d <- d[which(d$num.authors>0),]

# some journals publish large 'supplements' that contain conference many short conference abstracts
# (with results sections) in one file. Remove these
d <- d[-c(grep("(Suppl)", d$file.name)),]

# we have a few records in this dataset in which the journal.name wasn't extracted properly, we fix that here
d$journal.name <- as.character(d$journal.name)
fixed.names <- as.character(d$folder.name[which(is.na(d$journal.name))])
fixed.names <- gsub("_", " ", fixed.names)
d$journal.name[which(is.na(d$journal.name))] <- fixed.names
d$journal.name <- as.factor(d$journal.name)

# now we add in the FoR categories 
journal.categories$journal.name <- journal.categories$Abbreviation
d <- merge(d, journal.categories,by="journal.name")

# Include only exact p values which are less than 0.05
d <- d[d$p.value < 0.05, ]
d <- d[d$operator == "=", ]

# Now make two more datasets of just the p values from the Abstracts and the Results sections
d.results <- d[d$section == "results", ]
d.abstracts <- d[d$section == "abstract", ]

# Get rid of 'd' to save memory
rm(d)

# Remove excess factor levels from the datasets (there are plenty of empty ones, since we deleted some rows, and the empty levels would otherwise cause trouble later on)
d.results <- trim.levels(d.results)
d.abstracts <- trim.levels(d.abstracts)

##### Analysis on the entire dataset (i.e. not split by FoR category)
reps <- 1000
results.bias.test <- bootstrap.binomial.bias.test(d.results, reps)
abstract.bias.test <- bootstrap.binomial.bias.test(d.abstracts, reps)

write.csv(results.bias.test, file="processed_data/results.combined.data.csv")
write.csv(abstract.bias.test, file="processed_data/results.combined.data.abstracts.csv")


###### Analyses split by FoR category
results.FoR.test <- bootstrap.FoR.test(d.results, reps)
abstract.FoR.test <- bootstrap.FoR.test(d.abstracts, reps)

write.csv(results.FoR.test, file="processed_data/results.by.category.csv")
write.csv(abstract.FoR.test, file="processed_data/results.by.category.abstracts.csv")



# Making Figure 1 (was later fine-tuned in Inkscape)
both <- results.FoR.test[which(rowSums(cbind(results.FoR.test$binomial2.bias.lower, results.FoR.test$binomial2.bias.upper)) > 10), ]
both <- rbind(both,abstract.FoR.test[abstract.FoR.test$category %in% both$category, ])
both$section <- rep(c("Results", "Abstract"), each = 7)
both$n <- both$binomial2.bias.higher + both$binomial2.bias.lower
both$prop.upper <- both$binomial2.bias.higher / both$n
both$lowerCI <-NA
both$upperCI <- NA
for(i in 1:nrow(both)) both[i, c(ncol(both)-1, ncol(both))] <- as.numeric(binom.test(c(both[i,7], both[i,6]), alternative="greater")$conf)
both$category <- factor(both$category, levels = rev(sort(unique(both$category))))

library(RColorBrewer)
colors <- colorRampPalette(c("white","red"))

ggplot(both, aes(x = prop.upper, y = category))  + facet_wrap(~section) + geom_errorbarh(aes(xmin = lowerCI, xmax = upperCI),height=0.2) + geom_point(aes(colour=log(n)),pch=5, size=4) + geom_vline(x=0.5, linetype=2) + theme_bw() + scale_colour_gradient(low = "white", high = "red")



