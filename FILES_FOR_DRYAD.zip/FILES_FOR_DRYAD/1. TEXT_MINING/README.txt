README
------

Here's a description of each file and what's in it. All files created by Rob Lanfear 
unless specified otherwise.

analysis.r
----------
To recreate all the analyses in the paper, all you need to do is open up R and run this
script. The one thing you must change is the 'wd' parameter, and you just change that to 
the directory that contains the script.

functions.r
-----------
Contains a set of functions that are used in analysis.r

raw_data
--------
Contains all the raw data necessary to recreate the analyses in the paper

processed_data
--------------
Contains the output of all of the analyses. Running analysis.r overwrites these files. 
You can delete them and recreate them from scratch by running analysis.r.


Raw Data
========

p.values.csv
------------
This file contains all of the p values we extracted from the literature PubMedOA database 
(downloaded 11th June 2014). The first two columns are specific to each extracted p value. 
The rest of the columns refer to the .nxml file from which the p value was extracted 
(i.e. they are highly redundant but convenient for R). The Python scripts used to gather this
data form part of a separate publication (Lanfear, in prep).

Column descriptions.

p.value: p value extracted from the paper. "NA" for files with no p values
operator: operator (e.g. <, =, >) that precedes the p value
decimal places: the precision which p was reported
section: which section of the paper the p value was mined from
first.doi: the first DOI in the paper, 'NA' for papers without a DOI
num.dois: the number of DOIs reported in the paper (useful for excluding non-research papers - some .nxml files contain many documents so have many dois)
journal.name: name of the journal, extracted from the .nxml file itself
abstract.found: true or false
num.results.sections.found: number of results sections found. Occasionally we find > 1 results section particularly in papers which did not use the appropriate section tags. When >1 results section is found, we keep only the longest section.
num.authors: Number of authors, extracted from the .nxml file. 
year: Year of publication, extracted from the .nxml file.
file.name: .nxml file name. Combined with the folder.name column, this allows you to double check any of the .nxml files by hand, and also crossreference it with the published version using the first.doi column.
folder.name: folder in which the .nxml file is contained. Usually the same as journal.name, but kept because in occasionally we want to clean up journal.name (e.g. PLOS ONE has two names, so we change the journal name but not the folder name).

raw_data/p.values.one.per.paper.csv
----------------------------------------
This file is a subset of p.values.csv, and simply contains
one p value selected at random from each paper's results section. This file is the specific
version we used in our analyses. But it can be recreated (i.e. repeating the random selection
of p values) by setting recreate.random.datasets to "TRUE" in the analysis.r script.

The "Results" analyses we present in the paper are based on this files

raw_data/p.values.one.per.paper.abstracts.csv
----------------------------------------
This file is a subset of p.values.csv, and simply contains
one p value selected at random from each paper's Abstract. This file is the specific
version we used in our analyses. But it can be recreated (i.e. repeating the random selection
of p values) by setting recreate.random.datasets to "TRUE" in the analysis.r script.

The "Abstract" analyses we present in the paper are based on this files

raw_data/journal.categories.csv
-------------------------------
Our categorisation of each journal by name. Luke Holman created this file.


Processed Data
==============

processed_data/results.by.category.csv
----------------------------------------
Results of analyses on p values split by category.
The input data for this contain 1 p value sampled at random from each paper's results.

Note that the raw data were filtered as follows before any tests were carried out:

Only keep articles with:
>0 authors
exactly 1 unique DOI
at least 1 results section found
only p values reported exactly (i.e. with the '=' operator) and less than 0.05

Each row in this file corresponds to a single category. 

This file has 12 columns:

category: the name of the category, e.g. "Biological Sciences'
binomial.bias.p: p value from the binomial bias test with lower.limit set to 0.03
binomial.bias.lower: number of p values >=0.03 and <0.04
binomial.bias.higher: number of p values >=0.04 and <0.05
binomial.bias.effectsize: effect size calculated as number in higher bin divided by total

binomial2.bias.p: p value from the binomial bias test with lower.limit set to 0.04
binomial2.bias.lower: number of p values >0.04 and <0.045
binomial2.bias.higher: number of p values >0.045 and <0.05
binomial2.bias.effectsize: effect size calculated as number in higher bin divided by total

binomial.all.p: p value from the two-tailed test for evidential value
binomial.all.lower: number of p values >=0 and <0.025
binomial.all.higher: number of p values >0.025 and <0.05
binomial.all.effectsize: effect size calculated as number in bin with the most p values divided by total


processed_data/abstracts.by.category.csv
----------------------------------------
same as above but using Abstracts instead of Results sections