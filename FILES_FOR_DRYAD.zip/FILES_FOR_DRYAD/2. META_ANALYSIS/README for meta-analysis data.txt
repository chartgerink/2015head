READ ME
------
This Read me gives a description of the files associated with the manuscript "The extent and consequences of p-hacking in science"  by Megan L. Head, Luke Holman, Rob Lanfear, Andrew, T. Kahn & Michael D. Jennions   

Files and their descriptions:

phacking_metA_data for DRYAD. xlsx
------
This data file contains the p values associated with effect sizes from 16 meta-analyses the methods for obtaining the p-values are described in the supporting information associated with the manuscript(S1: Methods). The data is given in the worksheet "DATA" and descriptions of column headings are given in the worksheet "DESCRIPTION"

metA_analyses_rcode_for DRYAD.R
------
This file contains the R code used to run binomial tests on the data in phacking_metA_data for DRYAD.xlsx. These analyses are described in box 2 of the manuscript and the results are presented in Table 2 and Figure 2.


