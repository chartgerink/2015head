######################################################################################################
####  OVERALL TESTS FOR EVIDENTIAL VALUE AND P-HACKING IN META-ANALYSIS DATA AND TEXT MINED DATA  ####
######################################################################################################

########## Meta-analysis of meta-analyses

#### Testing for overall evidential value across meta-analyses

##Import data file: "meta_evid_cbind.csv"

meta_evid<-meta_evid_cbind
attach(meta_evid)
str(meta_evid)

Ymeta_evid<-cbind(upper,lower) 

meta_evid.mod<-glm(Ymeta_evid~1,family=binomial )
summary(meta_evid.mod)


#### Testing for overall p-hacking across meta-analyses
### Including p-values reported as <0.05 but calculated as greater than 0.05

## Import data file: "metacbind_forR.csv"

meta<-metacbind_forR
attach(meta)
str(meta)

Ymeta<-cbind(upper,lower) 

meta.mod<-glm(Ymeta~1,family=binomial )
summary(meta.mod)


#### Testing for overall p-hacking across meta-analyses
#### excluding p-values reported as <0.05 but calculated as greater than 0.05

## Import data file: "metacbind_forR_excluded.csv"

meta2<-metacbind_forR_excluded
attach(meta2)
str(meta2)

Ymeta2<-cbind(upper,lower) 

meta2.mod<-glm(Ymeta2~1,family=binomial )
summary(meta2.mod)


############  Meta-analysis of disciplines within text-mined data

#### Testing for overall evidential value across disciplines

#P-VALUES FROM RESULTS SECTION

## Import data file: "text_results_evid_cbind.csv"

text_R_evid<-text_results_evid_cbind
attach(text_R_evid)
str(text_R_evid)


Ytext_R_evid<-cbind(upper,lower) 

text_R_evid.mod<-glm(Ytext_R_evid~1,family=binomial )
summary(text_R_evid.mod)

#P-VALUES FROM ABSTRACTS

## Import data file: "text_abstracts_evid_cbind.csv"

text_A_evid<-text_abstracts_evid_cbind
attach(text_A_evid)
str(text_A_evid)


Ytext_A_evid<-cbind(upper,lower) 

text_A_evid.mod<-glm(Ytext_A_evid~1,family=binomial )
summary(text_A_evid.mod)



#### Testing for overall p-hacking across disciplines

#P-VALUES FROM RESULTS SECTION

## Import data file: "text_results_phack_cbind.csv"

text_R_phack<-text_results_phack_cbind
attach(text_R_phack)
str(text_R_phack)


Ytext_R_phack<-cbind(upper,lower) 

text_R_phack.mod<-glm(Ytext_R_phack~1,family=binomial )
summary(text_R_phack.mod)

#P-VALUES FROM ABSTRACTS

## Import data file: "text_abstracts_phack_cbind.csv"

text_A_phack<-text_abstracts_phack_cbind
attach(text_A_phack)
str(text_A_phack)


Ytext_A_phack<-cbind(upper,lower) 

text_A_phack.mod<-glm(Ytext_A_phack~1,family=binomial )
summary(text_A_phack.mod)





